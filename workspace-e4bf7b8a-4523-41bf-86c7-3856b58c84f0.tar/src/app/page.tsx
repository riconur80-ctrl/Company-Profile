"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { motion, useInView } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Building2,
  Shield,
  Truck,
  Ruler,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  CheckCircle2,
  Menu,
  X,
  ArrowUp,
  Wrench,
  Home,
} from "lucide-react";

/* ──────────────────────── Scroll Reveal Wrapper ──────────────────────── */
function Reveal({
  children,
  className = "",
  delay = 0,
  direction = "up",
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  direction?: "up" | "down" | "left" | "right";
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const dirMap = {
    up: { y: 40, x: 0 },
    down: { y: -40, x: 0 },
    left: { x: 40, y: 0 },
    right: { x: -40, y: 0 },
  };
  const d = dirMap[direction];

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: d.x, y: d.y }}
      animate={
        inView ? { opacity: 1, x: 0, y: 0 } : { opacity: 0, x: d.x, y: d.y }
      }
      transition={{ duration: 0.7, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ──────────────────────── Animated Counter ──────────────────────── */
function Counter({ end, suffix = "", prefix = "" }: { end: number; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (inView && !hasAnimated.current) {
      hasAnimated.current = true;
      const duration = 2000;
      const steps = 60;
      const increment = end / steps;
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(current));
        }
      }, duration / steps);
      return () => clearInterval(timer);
    }
  }, [inView, end]);

  return (
    <span ref={ref}>
      {prefix}
      {count}
      {suffix}
    </span>
  );
}

/* ──────────────────────── NAVBAR ──────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: "Beranda", href: "#beranda" },
    { label: "Tentang", href: "#tentang" },
    { label: "Layanan", href: "#layanan" },
    { label: "Proyek", href: "#proyek" },
    { label: "Kontak", href: "#kontak" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#0a0a0a]/95 backdrop-blur-md border-b border-[rgba(201,168,76,0.15)] py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <a href="#beranda" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-sm bg-gradient-to-br from-[#c9a84c] to-[#a88a30] flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
            <Building2 className="w-5 h-5 text-[#0a0a0a]" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-[0.2em] text-gold-gradient leading-tight">
              EZRIEL KHAIR
            </span>
            <span className="text-[10px] tracking-[0.15em] text-[#8a8a8a] leading-tight">
              UTAMA
            </span>
          </div>
        </a>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-8">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm tracking-wide text-[#8a8a8a] hover:text-[#c9a84c] transition-colors duration-300 relative after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-[1px] after:bg-[#c9a84c] hover:after:w-full after:transition-all after:duration-300"
            >
              {link.label}
            </a>
          ))}
          <a href="#kontak">
            <Button className="bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] hover:from-[#e2c97e] hover:to-[#c9a84c] font-semibold text-sm tracking-wide px-6 h-10 rounded-sm transition-all duration-300 shadow-lg shadow-[rgba(201,168,76,0.15)]">
              Hubungi Kami
            </Button>
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="lg:hidden text-[#c9a84c] p-2"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="lg:hidden bg-[#0a0a0a]/98 backdrop-blur-md border-t border-[rgba(201,168,76,0.15)]"
        >
          <div className="px-4 py-6 flex flex-col gap-4">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="text-sm tracking-wide text-[#8a8a8a] hover:text-[#c9a84c] transition-colors duration-300 py-2 border-b border-[rgba(201,168,76,0.08)]"
              >
                {link.label}
              </a>
            ))}
            <a href="#kontak" onClick={() => setMobileOpen(false)}>
              <Button className="w-full bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] font-semibold text-sm tracking-wide mt-2 rounded-sm">
                Hubungi Kami
              </Button>
            </a>
          </div>
        </motion.div>
      )}
    </nav>
  );
}

/* ──────────────────────── HERO ──────────────────────── */
function Hero() {
  return (
    <section
      id="beranda"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero.png"
          alt="PT EZRIEL KHAIR UTAMA - Baja Ringan"
          className="w-full h-full object-cover"
        />
        <div className="hero-overlay absolute inset-0" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 border border-[rgba(201,168,76,0.1)] rounded-full animate-float" />
      <div className="absolute bottom-40 right-20 w-20 h-20 border border-[rgba(201,168,76,0.08)] rotate-45 animate-float" style={{ animationDelay: "1.5s" }} />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <span className="inline-block text-[#c9a84c] text-xs sm:text-sm tracking-[0.3em] uppercase mb-6 border border-[rgba(201,168,76,0.3)] px-5 py-2 rounded-sm">
            Berdiri 2026 &middot; Terpercaya &amp; Berkualitas
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6"
        >
          <span className="text-white">Kekuatan Baja,</span>
          <br />
          <span className="text-gold-gradient">Keindahan Arsitektur</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="text-[#8a8a8a] text-base sm:text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          PT EZRIEL KHAIR UTAMA menghadirkan solusi baja ringan berkualitas
          tinggi yang menggabungkan kekuatan struktural dengan estetika modern
          untuk setiap proyek konstruksi Anda.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a href="#layanan">
            <Button
              size="lg"
              className="bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] hover:from-[#e2c97e] hover:to-[#c9a84c] font-semibold text-base tracking-wide px-8 h-12 rounded-sm transition-all duration-300 shadow-xl shadow-[rgba(201,168,76,0.2)]"
            >
              Jelajahi Layanan
              <ChevronRight className="ml-2 w-4 h-4" />
            </Button>
          </a>
          <a href="#tentang">
            <Button
              size="lg"
              variant="outline"
              className="border-[rgba(201,168,76,0.3)] text-[#c9a84c] hover:bg-[rgba(201,168,76,0.1)] hover:border-[#c9a84c] font-semibold text-base tracking-wide px-8 h-12 rounded-sm transition-all duration-300"
            >
              Tentang Kami
            </Button>
          </a>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 border-2 border-[rgba(201,168,76,0.4)] rounded-full flex justify-center pt-2">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              className="w-1.5 h-1.5 bg-[#c9a84c] rounded-full"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────── ABOUT ──────────────────────── */
function About() {
  return (
    <section id="tentang" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <Reveal direction="left">
            <div className="relative">
              <div className="relative overflow-hidden rounded-sm border-gold-glow">
                <img
                  src="/images/about.png"
                  alt="Fasilitas PT EZRIEL KHAIR UTAMA"
                  className="w-full h-[400px] md:h-[500px] object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-6 -right-4 sm:-right-6 bg-[#141414] border border-[rgba(201,168,76,0.3)] rounded-sm p-4 sm:p-6 shadow-2xl">
                <span className="text-3xl sm:text-4xl font-bold text-gold-gradient">15+</span>
                <p className="text-[#8a8a8a] text-xs sm:text-sm mt-1">Tahun Pengalaman</p>
              </div>
              {/* Decorative border */}
              <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-[rgba(201,168,76,0.3)] rounded-tl-sm" />
            </div>
          </Reveal>

          {/* Content Side */}
          <div>
            <Reveal>
              <span className="text-[#c9a84c] text-xs tracking-[0.3em] uppercase mb-4 block">
                Tentang Kami
              </span>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Membangun Masa Depan dengan{" "}
                <span className="text-gold-gradient">Baja Berkualitas</span>
              </h2>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="text-[#8a8a8a] leading-relaxed mb-6 text-sm sm:text-base">
                PT EZRIEL KHAIR UTAMA didirikan dengan visi menjadi penyedia
                solusi baja ringan terdepan di Indonesia. Dengan pengalaman lebih
                dari 15 tahun, kami telah menyelesaikan ratusan proyek di
                berbagai sektor — mulai dari perumahan, komersial, hingga
                industri.
              </p>
            </Reveal>
            <Reveal delay={0.3}>
              <p className="text-[#8a8a8a] leading-relaxed mb-8 text-sm sm:text-base">
                Kami menggunakan material baja ringan berkualitas tinggi dengan
                standar SNI dan dilengkapi tim profesional yang berpengalaman.
                Setiap proyek kami tangani dengan presisi, ketelitian, dan
                komitmen terhadap kualitas terbaik.
              </p>
            </Reveal>
            <Reveal delay={0.4}>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { icon: Shield, text: "Bersertifikat SNI" },
                  { icon: Wrench, text: "Tim Profesional" },
                  { icon: Truck, text: "Pengiriman Cepat" },
                  { icon: CheckCircle2, text: "Pelayanan Terbaik" },
                ].map((item) => (
                  <div
                    key={item.text}
                    className="flex items-center gap-3 p-3 rounded-sm bg-[#141414] border border-[rgba(201,168,76,0.08)]"
                  >
                    <item.icon className="w-5 h-5 text-[#c9a84c] shrink-0" />
                    <span className="text-sm text-[#c9c9c9]">{item.text}</span>
                  </div>
                ))}
              </div>
            </Reveal>
            <Reveal delay={0.5}>
              <a href="#kontak">
                <Button className="bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] hover:from-[#e2c97e] hover:to-[#c9a84c] font-semibold text-sm tracking-wide px-8 h-11 rounded-sm transition-all duration-300">
                  Konsultasi Gratis
                  <ChevronRight className="ml-2 w-4 h-4" />
                </Button>
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── SERVICES ──────────────────────── */
const services = [
  {
    icon: Home,
    title: "Atap Baja Ringan",
    description:
      "Solusi atap ringan, kuat, dan tahan lama untuk rumah tinggal, ruko, dan bangunan komersial dengan berbagai pilihan model.",
  },
  {
    icon: Building2,
    title: "Kanopi Baja Ringan",
    description:
      "Kanopi elegan dan fungsional untuk carport, teras, dan area outdoor dengan desain modern dan material premium.",
  },

  {
    icon: Ruler,
    title: "Pagar & Pintu Gerbang",
    description:
      "Pagar dan pintu gerbang dari baja ringan dengan desain minimalis hingga klasik, keamanan terjamin.",
  },
  {
    icon: Ruler,
    title: "Rangka Plafon",
    description:
      "Rangka plafon baja ringan yang presisi, anti rayap, dan tahan lama untuk interior maupun eksterior bangunan.",
  },

];

function Services() {
  return (
    <section id="layanan" className="py-20 md:py-28 bg-[#111111]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Reveal>
            <span className="text-[#c9a84c] text-xs tracking-[0.3em] uppercase mb-4 block">
              Layanan Kami
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              Solusi <span className="text-gold-gradient">Lengkap</span> Baja
              Ringan
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-[#8a8a8a] max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
              Kami menyediakan berbagai layanan konstruksi baja ringan yang
              disesuaikan dengan kebutuhan spesifik proyek Anda.
            </p>
          </Reveal>
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 0.1}>
              <div className="card-elegant group relative bg-[#141414] border border-[rgba(201,168,76,0.08)] rounded-sm p-6 sm:p-8 h-full">
                {/* Icon */}
                <div className="w-14 h-14 rounded-sm bg-[rgba(201,168,76,0.08)] border border-[rgba(201,168,76,0.15)] flex items-center justify-center mb-6 group-hover:bg-[rgba(201,168,76,0.15)] group-hover:border-[rgba(201,168,76,0.3)] transition-all duration-300">
                  <service.icon className="w-7 h-7 text-[#c9a84c]" />
                </div>

                <h3 className="text-lg sm:text-xl font-semibold text-white mb-3 group-hover:text-[#c9a84c] transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-[#8a8a8a] text-sm leading-relaxed">
                  {service.description}
                </p>

                {/* Bottom accent line */}
                <div className="absolute bottom-0 left-6 right-6 h-[2px] bg-gradient-to-r from-transparent via-[#c9a84c] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── STATISTICS ──────────────────────── */
const stats = [
  { value: 500, suffix: "+", label: "Proyek Selesai" },
  { value: 15, suffix: "+", label: "Tahun Pengalaman" },
  { value: 350, suffix: "+", label: "Klien Puas" },
  { value: 50, suffix: "+", label: "Tim Profesional" },
];

function Statistics() {
  return (
    <section className="py-20 md:py-28 bg-[#0a0a0a] relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#c9a84c] rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#c9a84c] rounded-full blur-[120px]" />
      </div>

      <div className="section-divider max-w-7xl mx-auto mb-20" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 0.15}>
              <div className="text-center">
                <div className="text-4xl sm:text-5xl md:text-6xl font-bold text-gold-gradient mb-3">
                  <Counter end={stat.value} suffix={stat.suffix} />
                </div>
                <p className="text-[#8a8a8a] text-sm sm:text-base tracking-wide">
                  {stat.label}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      <div className="section-divider max-w-7xl mx-auto mt-20" />
    </section>
  );
}

/* ──────────────────────── PROJECTS ──────────────────────── */
const projects = [
  {
    image: "/images/project1.png",
    title: "Residensi Harmoni",
    category: "Perumahan",
    description:
      "Konstruksi atap baja ringan untuk kompleks perumahan mewah dengan 120 unit rumah bergaya tropis modern.",
  },
  {
    image: "/images/project2.png",
    title: "Gudang Logistik Nusantara",
    category: "Komersial",
    description:
      "Pembangunan gudang logistik seluas 2.500 m² dengan struktur baja ringan span lebar tanpa kolom tengah.",
  },

];

function Projects() {
  return (
    <section id="proyek" className="py-20 md:py-28 bg-[#111111]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Reveal>
            <span className="text-[#c9a84c] text-xs tracking-[0.3em] uppercase mb-4 block">
              Portfolio
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              Proyek <span className="text-gold-gradient">Unggulan</span> Kami
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-[#8a8a8a] max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
              Beberapa proyek yang telah kami selesaikan dengan standar kualitas
              tertinggi dan kepuasan klien.
            </p>
          </Reveal>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, i) => (
            <Reveal key={project.title} delay={i * 0.15}>
              <div className="group card-elegant bg-[#141414] border border-[rgba(201,168,76,0.08)] rounded-sm overflow-hidden h-full">
                {/* Image */}
                <div className="relative overflow-hidden h-64">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="img-overlay absolute inset-0" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-[rgba(201,168,76,0.9)] text-[#0a0a0a] text-xs font-semibold tracking-wider uppercase px-3 py-1 rounded-sm">
                      {project.category}
                    </span>
                  </div>
                </div>
                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-[#c9a84c] transition-colors duration-300">
                    {project.title}
                  </h3>
                  <p className="text-[#8a8a8a] text-sm leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── TESTIMONIALS ──────────────────────── */


/* ──────────────────────── WHY CHOOSE US ──────────────────────── */
const reasons = [
  {
    title: "Material Berkualitas Tinggi",
    description:
      "Menggunakan baja ringan dengan standar SNI dan sertifikasi internasional, tahan karat dan korosi.",
  },
  {
    title: "Tim Berpengalaman",
    description:
      "Didukung oleh insinyur dan teknisi berpengalaman yang terlatih dalam standar keselamatan kerja.",
  },
  {
    title: "Harga Kompetitif",
    description:
      "Penawaran harga transparan dan bersaing tanpa mengorbankan kualitas material maupun pengerjaan.",
  },
  {
    title: "Tepat Waktu",
    description:
      "Komitmen penyelesaian proyek sesuai jadwal yang disepakati, dengan sistem manajemen proyek terstruktur.",
  },
];

function WhyChooseUs() {
  return (
    <section className="py-20 md:py-28 bg-[#111111] relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-[rgba(201,168,76,0.03)] rounded-full blur-[100px]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div>
            <Reveal>
              <span className="text-[#c9a84c] text-xs tracking-[0.3em] uppercase mb-4 block">
                Mengapa Kami
              </span>
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Keunggulan{" "}
                <span className="text-gold-gradient">EZRIEL KHAIR UTAMA</span>
              </h2>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="text-[#8a8a8a] leading-relaxed mb-10 text-sm sm:text-base">
                Kami berkomitmen untuk memberikan yang terbaik di setiap proyek.
                Berikut alasan mengapa ratusan klien mempercayakan kebutuhan baja
                ringan mereka kepada kami.
              </p>
            </Reveal>

            <div className="space-y-6">
              {reasons.map((reason, i) => (
                <Reveal key={reason.title} delay={i * 0.1 + 0.3}>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-sm bg-[rgba(201,168,76,0.1)] border border-[rgba(201,168,76,0.2)] flex items-center justify-center shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-[#c9a84c]" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-sm sm:text-base mb-1">
                        {reason.title}
                      </h3>
                      <p className="text-[#8a8a8a] text-sm leading-relaxed">
                        {reason.description}
                      </p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Visual Side */}
          <Reveal direction="right">
            <div className="relative">
              <div className="bg-[#141414] border border-[rgba(201,168,76,0.15)] rounded-sm p-8 sm:p-10">
                <h3 className="text-2xl font-bold text-white mb-6">
                  Butuh <span className="text-gold-gradient">Penawaran</span>?
                </h3>
                <p className="text-[#8a8a8a] text-sm leading-relaxed mb-8">
                  Dapatkan penawaran harga gratis untuk proyek Anda. Tim kami
                  akan merespon dalam 24 jam kerja.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm text-[#c9c9c9]">
                    <Phone className="w-4 h-4 text-[#c9a84c]" />
                    <span>+62 857 2609 7031</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-[#c9c9c9]">
                    <Mail className="w-4 h-4 text-[#c9a84c]" />
                    <span>ezrielkhairutama@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-[#c9c9c9]">
                    <MapPin className="w-4 h-4 text-[#c9a84c]" />
                    <span>Gresik, Jawa Timur</span>
                  </div>
                </div>
                <div className="mt-8 pt-6 border-t border-[rgba(201,168,76,0.1)]">
                  <a href="#kontak">
                    <Button className="w-full bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] hover:from-[#e2c97e] hover:to-[#c9a84c] font-semibold text-sm tracking-wide h-11 rounded-sm transition-all duration-300">
                      Minta Penawaran
                      <ChevronRight className="ml-2 w-4 h-4" />
                    </Button>
                  </a>
                </div>
              </div>
              {/* Decorative */}
              <div className="absolute -bottom-4 -left-4 w-24 h-24 border-b-2 border-l-2 border-[rgba(201,168,76,0.3)] rounded-bl-sm" />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── CONTACT ──────────────────────── */
function Contact() {
  const [formState, setFormState] = useState({
    name: "",
    phone: "",
    email: "",
    service: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate submission
    await new Promise((r) => setTimeout(r, 1500));
    setIsSubmitting(false);
    setSubmitted(true);
    setFormState({ name: "", phone: "", email: "", service: "", message: "" });
    setTimeout(() => setSubmitted(false), 5000);
  }, []);

  return (
    <section id="kontak" className="py-20 md:py-28 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <Reveal>
            <span className="text-[#c9a84c] text-xs tracking-[0.3em] uppercase mb-4 block">
              Hubungi Kami
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              Mari <span className="text-gold-gradient">Berdiskusi</span>
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-[#8a8a8a] max-w-2xl mx-auto text-sm sm:text-base leading-relaxed">
              Hubungi kami untuk konsultasi gratis dan penawaran harga terbaik
              untuk proyek Anda.
            </p>
          </Reveal>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Contact Info */}
          <Reveal direction="left" className="lg:col-span-2">
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold text-white mb-6">
                  Informasi Kontak
                </h3>
                <div className="space-y-6">
                  {[
                    {
                      icon: Phone,
                      label: "Telepon",
                      value: "+62 857 2609 7031",
                      sub: "Senin - Sabtu, 08:00 - 17:00",
                    },
                    {
                      icon: Mail,
                      label: "Email",
                      value: "ezrielkhairutama@gmail.com",
                      sub: "Respon dalam 24 jam kerja",
                    },
                    {
                      icon: MapPin,
                      label: "Alamat",
                      value:
                        "Perum Sumput Asri Gg Flamboyan Blok BY-3, Kec. Driyorejo, Kab. Gresik 61177",
                      sub: "",
                    },
                  ].map((item) => (
                    <div key={item.label} className="flex gap-4">
                      <div className="w-12 h-12 rounded-sm bg-[rgba(201,168,76,0.08)] border border-[rgba(201,168,76,0.15)] flex items-center justify-center shrink-0">
                        <item.icon className="w-5 h-5 text-[#c9a84c]" />
                      </div>
                      <div>
                        <p className="text-[#8a8a8a] text-xs tracking-wider uppercase mb-1">
                          {item.label}
                        </p>
                        <p className="text-white text-sm font-medium">
                          {item.value}
                        </p>
                        {item.sub && (
                          <p className="text-[#8a8a8a] text-xs mt-0.5">
                            {item.sub}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          {/* Contact Form */}
          <Reveal direction="right" className="lg:col-span-3">
            <form
              onSubmit={handleSubmit}
              className="bg-[#141414] border border-[rgba(201,168,76,0.08)] rounded-sm p-6 sm:p-8"
            >
              <div className="grid sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs text-[#8a8a8a] tracking-wider uppercase mb-2 block">
                    Nama Lengkap
                  </label>
                  <Input
                    required
                    value={formState.name}
                    onChange={(e) =>
                      setFormState({ ...formState, name: e.target.value })
                    }
                    placeholder="Masukkan nama Anda"
                    className="bg-[#0a0a0a] border-[rgba(201,168,76,0.15)] text-white placeholder:text-[#555] rounded-sm h-11 focus:border-[#c9a84c] focus:ring-[rgba(201,168,76,0.2)]"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#8a8a8a] tracking-wider uppercase mb-2 block">
                    No. Telepon
                  </label>
                  <Input
                    required
                    value={formState.phone}
                    onChange={(e) =>
                      setFormState({ ...formState, phone: e.target.value })
                    }
                    placeholder="08xx-xxxx-xxxx"
                    className="bg-[#0a0a0a] border-[rgba(201,168,76,0.15)] text-white placeholder:text-[#555] rounded-sm h-11 focus:border-[#c9a84c] focus:ring-[rgba(201,168,76,0.2)]"
                  />
                </div>
              </div>
              <div className="mb-4">
                <label className="text-xs text-[#8a8a8a] tracking-wider uppercase mb-2 block">
                  Email
                </label>
                <Input
                  type="email"
                  required
                  value={formState.email}
                  onChange={(e) =>
                    setFormState({ ...formState, email: e.target.value })
                  }
                  placeholder="email@contoh.com"
                  className="bg-[#0a0a0a] border-[rgba(201,168,76,0.15)] text-white placeholder:text-[#555] rounded-sm h-11 focus:border-[#c9a84c] focus:ring-[rgba(201,168,76,0.2)]"
                />
              </div>
              <div className="mb-4">
                <label className="text-xs text-[#8a8a8a] tracking-wider uppercase mb-2 block">
                  Layanan yang Dibutuhkan
                </label>
                <select
                  required
                  value={formState.service}
                  onChange={(e) =>
                    setFormState({ ...formState, service: e.target.value })
                  }
                  className="w-full bg-[#0a0a0a] border border-[rgba(201,168,76,0.15)] text-white rounded-sm h-11 px-3 text-sm focus:border-[#c9a84c] focus:ring-[rgba(201,168,76,0.2)] focus:outline-none appearance-none cursor-pointer"
                >
                  <option value="" disabled>
                    Pilih layanan...
                  </option>
                  <option value="atap">Atap Baja Ringan</option>
                  <option value="kanopi">Kanopi Baja Ringan</option>

                  <option value="pagar">Pagar & Pintu Gerbang</option>
                  <option value="plafon">Rangka Plafon</option>
                  <option value="lainnya">Lainnya</option>
                </select>
              </div>
              <div className="mb-6">
                <label className="text-xs text-[#8a8a8a] tracking-wider uppercase mb-2 block">
                  Pesan
                </label>
                <Textarea
                  required
                  value={formState.message}
                  onChange={(e) =>
                    setFormState({ ...formState, message: e.target.value })
                  }
                  placeholder="Ceritakan kebutuhan proyek Anda..."
                  rows={4}
                  className="bg-[#0a0a0a] border-[rgba(201,168,76,0.15)] text-white placeholder:text-[#555] rounded-sm focus:border-[#c9a84c] focus:ring-[rgba(201,168,76,0.2)] resize-none"
                />
              </div>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] hover:from-[#e2c97e] hover:to-[#c9a84c] font-semibold text-sm tracking-wide h-12 rounded-sm transition-all duration-300 disabled:opacity-60"
              >
                {isSubmitting
                  ? "Mengirim..."
                  : submitted
                    ? "Pesan Terkirim!"
                    : "Kirim Pesan"}
              </Button>
              {submitted && (
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-[#c9a84c] text-sm text-center mt-3"
                >
                  Terima kasih! Tim kami akan menghubungi Anda segera.
                </motion.p>
              )}
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── FOOTER ──────────────────────── */
function Footer() {
  return (
    <footer className="bg-[#060606] border-t border-[rgba(201,168,76,0.1)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-12">
          {/* Company Info */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-sm bg-gradient-to-br from-[#c9a84c] to-[#a88a30] flex items-center justify-center">
                <Building2 className="w-5 h-5 text-[#0a0a0a]" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold tracking-[0.2em] text-gold-gradient leading-tight">
                  EZRIEL KHAIR
                </span>
                <span className="text-[10px] tracking-[0.15em] text-[#8a8a8a] leading-tight">
                  UTAMA
                </span>
              </div>
            </div>
            <p className="text-[#8a8a8a] text-sm leading-relaxed">
              Solusi baja ringan terpercaya untuk kebutuhan konstruksi Anda.
              Kualitas terbaik, harga bersaing.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-sm tracking-wider uppercase mb-4">
              Navigasi
            </h4>
            <ul className="space-y-3">
              {[
                { label: "Beranda", href: "#beranda" },
                { label: "Tentang Kami", href: "#tentang" },
                { label: "Layanan", href: "#layanan" },
                { label: "Proyek", href: "#proyek" },

              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-[#8a8a8a] text-sm hover:text-[#c9a84c] transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-sm tracking-wider uppercase mb-4">
              Layanan
            </h4>
            <ul className="space-y-3">
              {[
                "Atap Baja Ringan",
                "Kanopi Baja Ringan",
                "Pagar & Pintu Gerbang",
                "Rangka Plafon",
              ].map((s) => (
                <li key={s}>
                  <a
                    href="#layanan"
                    className="text-[#8a8a8a] text-sm hover:text-[#c9a84c] transition-colors duration-300"
                  >
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-sm tracking-wider uppercase mb-4">
              Kontak
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-[#8a8a8a]">
                <MapPin className="w-4 h-4 text-[#c9a84c] shrink-0 mt-0.5" />
                <span>
                  Perum Sumput Asri Gg Flamboyan Blok BY-3, Gresik
                </span>
              </li>
              <li className="flex items-center gap-2 text-sm text-[#8a8a8a]">
                <Phone className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span>+62 857 2609 7031</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-[#8a8a8a]">
                <Mail className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span>ezrielkhairutama@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="section-divider mb-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[#555] text-xs">
            &copy; {new Date().getFullYear()} PT EZRIEL KHAIR UTAMA. Seluruh hak
            cipta dilindungi.
          </p>
          <div className="flex gap-6">
            <a
              href="#"
              className="text-[#555] text-xs hover:text-[#c9a84c] transition-colors duration-300"
            >
              Kebijakan Privasi
            </a>
            <a
              href="#"
              className="text-[#555] text-xs hover:text-[#c9a84c] transition-colors duration-300"
            >
              Syarat & Ketentuan
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

/* ──────────────────────── SCROLL TO TOP ──────────────────────── */
function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.button
      initial={{ opacity: 0 }}
      animate={{ opacity: visible ? 1 : 0 }}
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-6 right-6 z-50 w-12 h-12 bg-gradient-to-br from-[#c9a84c] to-[#a88a30] text-[#0a0a0a] rounded-full flex items-center justify-center shadow-lg shadow-[rgba(201,168,76,0.2)] hover:from-[#e2c97e] hover:to-[#c9a84c] transition-all duration-300"
      aria-label="Scroll to top"
    >
      <ArrowUp className="w-5 h-5" />
    </motion.button>
  );
}

/* ──────────────────────── MAIN PAGE ──────────────────────── */
export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#0a0a0a]">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Statistics />
      <Projects />
      <WhyChooseUs />
      <Contact />
      <Footer />
      <ScrollToTop />
    </main>
  );
}