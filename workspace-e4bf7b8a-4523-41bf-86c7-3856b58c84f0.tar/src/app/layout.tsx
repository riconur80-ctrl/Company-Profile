import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PT EZRIEL KHAIR UTAMA | Solusi Baja Ringan Terpercaya",
  description:
    "PT EZRIEL KHAIR UTAMA adalah perusahaan terkemuka yang menyediakan solusi baja ringan berkualitas tinggi untuk konstruksi rumah, komersial, dan industrial. Kualitas terbaik, harga bersaing.",
  keywords: [
    "baja ringan",
    "konstruksi baja",
    "atap baja ringan",
    "PT EZRIEL KHAIR UTAMA",
    "kanopi baja ringan",
    "pagar baja ringan",
    "konstruksi",
  ],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "PT EZRIEL KHAIR UTAMA | Solusi Baja Ringan Terpercaya",
    description:
      "Solusi baja ringan berkualitas tinggi untuk kebutuhan konstruksi Anda.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}